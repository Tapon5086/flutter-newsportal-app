package com.example.mad_lab_project_new

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
